import cv2
import speech_recognition as sr
import tkinter as tk
from tkinter import messagebox

def detect_fire_and_listen():

    fire_cascade = cv2.CascadeClassifier('cascade.xml')

    cap = cv2.VideoCapture(0)

    recognizer = sr.Recognizer()
    while True:
        ret, frame = cap.read()

        if ret:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            fires = fire_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

            for (x, y, w, h) in fires:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

            cv2.imshow('Frame', frame)

            with sr.Microphone() as source:
                print("Say a word:")
                audio = recognizer.listen(source)

                try:
                    word = recognizer.recognize_google(audio, language='en')
                    print(f"Recognized: {word}")

                    if 'earthquake' in word:
                        result = "earthquake"
                        return result
                        print(result)
                    if 'fire'in word:
                        result = "fire"
                        return result
                        print(result)
                        

                except sr.UnknownValueError:
                    print("Speech not recognized")
                

            if cv2.waitKey(1) & 0xFF == ord('q'):
                
                break


